﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;

namespace Fingerprint_Authentication.Windows_Forms
{
    public partial class FP_Comparision : Form
    {
        Bitmap bitmap1, bitmap2;
        public FP_Comparision()
        {
            InitializeComponent();
        }
      
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openflg = new OpenFileDialog();
            if (openflg.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.ImageLocation = openflg.FileName;
                bitmap1 = new Bitmap(openflg.FileName);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openflg = new OpenFileDialog();
            if (openflg.ShowDialog() == DialogResult.OK)
            {
                pictureBox2.ImageLocation = openflg.FileName;
                bitmap2 = new Bitmap(openflg.FileName);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            bool compare = ImageCompareString(bitmap1, bitmap2);
            if (compare == true)
            {
               // MessageBox.Show("Access Granted");
                this.Hide();
                ATM_Operation next = new ATM_Operation();
                next.Show();
            }
            else
            {
                MessageBox.Show("Access Denied");
            }
        }
        private bool ImageCompareString(Bitmap bitmap11, Bitmap bitmap21)

        {
            //   throw new NotImplementedException();
            MemoryStream ms = new MemoryStream();

            bitmap11.Save(ms, ImageFormat.Png);
            string firstbitmap = Convert.ToBase64String(ms.ToArray());
            ms.Position = 0;

            bitmap21.Save(ms, ImageFormat.Png);
            string secondbitmap = Convert.ToBase64String(ms.ToArray());
            ms.Position = 0;

            if (firstbitmap.Equals(secondbitmap))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
