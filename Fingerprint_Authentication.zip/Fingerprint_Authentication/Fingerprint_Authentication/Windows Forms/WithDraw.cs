﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fingerprint_Authentication.Windows_Forms
{
    public partial class WithDraw : Form
    {
        public WithDraw()
        {
            InitializeComponent();
        }
        int flag = 1, click = 1, count = 1;
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            txtb_input.Text += 1;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtb_input.Text += 2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtb_input.Text += 3;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            txtb_input.Text += 4;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            txtb_input.Text += 5;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            txtb_input.Text += 6;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            txtb_input.Text += 7;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            txtb_input.Text += 8;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            txtb_input.Text += 9;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            txtb_input.Text += 0;
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
        
        }

        private void Correction_Click(object sender, EventArgs e)
        {
            txtb_input.Text = "";
        }

        private void Next_Click(object sender, EventArgs e)
        {
            click = 1;

            if (click == 1)
            {
                
            }
        }

        private void Enterr_Click(object sender, EventArgs e)
        {
    
       
            
        }
    


        private void pictureBox2_Click(object sender, EventArgs e)
        {
            
        }
    }
}
